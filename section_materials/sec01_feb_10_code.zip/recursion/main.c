#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "recursion.h"

int main(void) {
  char s1[] = "Hello, world!";
  char s2[] = "Recursion is fun";

  rev_str(s1, 0, (int)strlen(s1));
  assert(0 == strcmp(s1, "!dlrow ,olleH"));

  rev_str(s2, 0, (int)strlen(s2));
  assert(0 == strcmp(s2, "nuf si noisruceR"));

  printf("All tests passed\n");
  return 0;
}
