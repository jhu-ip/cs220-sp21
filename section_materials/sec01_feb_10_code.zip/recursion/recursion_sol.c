#include <stdio.h>
#include <string.h>
#include <assert.h>

void rev_str(char str[], int start, int end);

int main(void) {
  char s1[] = "Hello, world!";
  char s2[] = "Recursion is fun";

  rev_str(s1, 0, (int)strlen(s1));
  assert(0 == strcmp(s1, "!dlrow ,olleH"));

  rev_str(s2, 0, (int)strlen(s2));
  assert(0 == strcmp(s2, "nuf si noisruceR"));

  printf("All tests passed\n");
  return 0;
}

void rev_str(char str[], int start, int end) {
  int n = end - start;
  if (n < 1) {
    // sequence has 0 or 1 characters, nothing to do
    return;
  }

  // swap first and last characters in sequence
  char tmp = str[start];
  str[start] = str[end-1];
  str[end-1] = tmp;

  // reverse the remaining characters (if any)
  rev_str(str, start + 1, end - 1);
}
