#ifndef RECURSION_H
#define RECURSION_H

void rev_str(char str[], int start, int end);

#endif // RECURSION_H


