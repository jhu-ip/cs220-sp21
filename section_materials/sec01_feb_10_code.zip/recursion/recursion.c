#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "recursion.h"

void rev_str(char str[], int start, int end) {
  int n = end - start;
  if (n < 1) {
    // sequence has 0 or 1 characters, nothing to do
    return;
  }

  // swap first and last characters in sequence
  char tmp = str[start];
  str[start] = str[end-1];
  str[end-1] = tmp;

  // reverse the remaining characters (if any)
  rev_str(str, start + 1, end - 1);
}
