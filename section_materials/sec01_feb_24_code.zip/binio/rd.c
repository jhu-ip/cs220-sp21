#include <stdio.h>

int main(void) {
  char c;
  unsigned char d;
  int x;
  float y;

  FILE *in = fopen("bin.out", "rb");
  fread(&c, sizeof(char), 1, in);
  fread(&d, sizeof(unsigned char), 1, in);
  fread(&x, sizeof(int), 1, in);
  fread(&y, sizeof(float), 1, in);

  fclose(in);

  printf("It worked?\n");

  printf("%c %u %d %f\n", c, d, x, y);

  return 0;
}
