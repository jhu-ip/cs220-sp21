#include <stdio.h>

int main(void) {
  float f = 123.45;
  printf("%f\n", f & 128);
  return 0;
}
