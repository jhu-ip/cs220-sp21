#include <stdio.h>

int main(void) {
  char c = 'U';
  unsigned char d = 145;
  int x = 128461;
  float y = -121564.3;

  FILE *out = fopen("bin.out", "wb");
  fwrite(&c, sizeof(char), 1, out);
  fwrite(&d, sizeof(unsigned char), 1, out);
  fwrite(&x, sizeof(int), 1, out);
  fwrite(&y, sizeof(float), 1, out);

  fclose(out);

  printf("It worked?\n");

  return 0;
}
