#include <stdio.h>

int main(void) {
  int n;
  printf("enter an integer: ");
  int rc = scanf("%d", &n);
  if (rc == 1) {
    printf("You entered: %d\n", n);
  } else {
    // scanf failed
    if (feof(stdin)) {
      printf("end of input\n");
    }
    if (ferror(stdin)) {
      printf("input error\n");
    }
  }
  return 0;
}
